package assignment7;

import java.util.Observable;
import java.util.Observer;

/**
 * Created by Ali Kedwaii on 4/29/2017.
 */
public class Client implements Observer {

    @Override
    public void update(Observable o, Object arg) {

    }
}
